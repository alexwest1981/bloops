using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class MergeManager : MonoBehaviour
{
    

    [Header(" Actions")]
    public static Action<BloopType, Vector2> onMergeProcessed;

    [Header(" Settings")]
    Bloop lastSender;

    // Start is called before the first frame update
    void Awake()
    {
        Bloop.onCollisionWithBloop += CollisionBetweenBloopsCallback;
    }

    private void OnDestroy()
    {
        Bloop.onCollisionWithBloop -= CollisionBetweenBloopsCallback;
    }


    void Start()
    {
        
    }
    // Update is called once per frame
    void Update()
    {
        
    }


    private void CollisionBetweenBloopsCallback(Bloop sender, Bloop otherBloop)
    {
        if(lastSender != null)
                return;

        lastSender = sender;

        ProcessMerge(sender, otherBloop);

    }

    private void ProcessMerge(Bloop sender, Bloop otherBloop)
    {
        BloopType mergeBloopType = sender.GetBloopType();
        mergeBloopType += 1;

        Vector2 bloopSpawnPos = (sender.transform.position + otherBloop.transform.position) / 2;

        Destroy(sender.gameObject);
        Destroy(otherBloop.gameObject);

        StartCoroutine(ResetLastSenderCoroutine());

        onMergeProcessed?.Invoke(mergeBloopType, bloopSpawnPos);
        
    }

    IEnumerator ResetLastSenderCoroutine()
    {
        yield return new WaitForEndOfFrame();
        lastSender = null;
    }

}
