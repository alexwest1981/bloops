using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GameOverManager : MonoBehaviour
{


    [Header(" Elements ")]
    [SerializeField] private GameObject deadLine;
    [SerializeField] private Transform bloopsParent;

    [Header(" Timer ")]
    [SerializeField] private float durationThreshold;
    private float timer;
    private bool timerOn;
    private bool isGameOver = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(!isGameOver)
            ManageGameover();

        

    }

    private void ManageGameover()
    {
        if (timerOn)
        {
            ManageTimerOn();
        }
        else
        {
            if (IsBloopAboveLine())
                StartTimer();

        }
    }


    private void ManageTimerOn()
    {
        
        timer += Time.deltaTime;

        if (!IsBloopAboveLine())
                StopTimer();

        if (timer >= durationThreshold)
        {
            GameOver();
        }
        
    }

    private bool IsBloopAboveLine()
    {
        for (int i = 0; i < bloopsParent.childCount; i++)
        {
            Bloop bloop = bloopsParent.GetChild(i).GetComponent<Bloop>();

            if (!bloop.HasCollided())
                continue;

            if (IsBloopAboveLine(bloopsParent.GetChild(i)))
                return true;
        }

        return false;
    }

    

    private bool IsBloopAboveLine(Transform bloop)
    {
        if (bloop.position.y > deadLine.transform.position.y)
            return true;
        return false;
    }

    private void StartTimer()
    {
        timer = 0;
        timerOn = true;
    }

    private void StopTimer()
    {
        timerOn = false;
    }

    private void GameOver()
    {
        Debug.Log("Game Over");
        isGameOver = true;

        GameManager.instance.SetGameOverState();
    }

}
