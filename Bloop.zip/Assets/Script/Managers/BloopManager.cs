using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UIElements;

using Random = UnityEngine.Random;

public class BloopManager : MonoBehaviour
{

    [Header(" Elements ")]
    [SerializeField] private Bloop[] bloopPrefabs;
    [SerializeField] private Bloop[] spawnableBloops;
    [SerializeField] private Transform bloopParent;
    [SerializeField] private LineRenderer bloopDropLine;
    private Bloop currentBloop;


    [Header(" Settings ")]
    [SerializeField] private float bloopYSpawnPos;
    [SerializeField] private float spawnDelay;
    private bool canControl;
    private bool isControlling;


    [Header(" Next Bloop Settings ")]
    private int nextBloopIndex;

    [Header(" Debug ")]
    [SerializeField] private bool enableGizmos;

    [Header(" Actions")]
    public static Action onNextBloopIndexSet;

    private void Awake()
    {
        MergeManager.onMergeProcessed += MergeProcessedCallback;
    }

    private void OnDestroy()
    {
        MergeManager.onMergeProcessed -= MergeProcessedCallback;
    }

    // Start is called before the first frame update
    void Start()
    {
        SetNextBloopIndex();

        canControl = true;
        HideLine();
    }

    // Update is called once per frame
    void Update()
    {
        if(!GameManager.instance.IsGameState())
            return;

        if (canControl)
            ManagePlayerInput();
    }

    private void ManagePlayerInput()
    {
        if (Input.GetMouseButtonDown(0))
            MouseDownCallback();

        else if (Input.GetMouseButton(0))
        {
            if (isControlling)
                MouseDragCallback();
            else
                MouseDownCallback();
        }
            

        else if (Input.GetMouseButtonUp(0) && isControlling)
            MouseUpCallback();
    }

    private void MouseDownCallback()
    {
        DisplayLine();

        PlaceLineAtClickedPosition();

        SpawnBloop();
        isControlling = true;
    }

    private void MouseDragCallback()
    {
        PlaceLineAtClickedPosition();

        currentBloop.MoveTo(GetSpawnPosition());
    }

    private void MouseUpCallback()
    {
        HideLine();

        if(currentBloop != null)
            currentBloop.EnablePhysics();

        canControl = false;
        StartControlTimer();
    }

    private void SpawnBloop()
    {
        Vector2 spawnPosition = GetSpawnPosition();
        Bloop bloopToInstantiate = spawnableBloops[nextBloopIndex];

        currentBloop = Instantiate(
            bloopToInstantiate, 
            spawnPosition, 
            Quaternion.identity, 
            bloopParent);

        SetNextBloopIndex();
    }

    private void SetNextBloopIndex()
    {
        nextBloopIndex = UnityEngine.Random.Range(0, spawnableBloops.Length);
        onNextBloopIndexSet?.Invoke();
    }

    public string GetNextBloopName()
    {
        return spawnableBloops[nextBloopIndex].name;
    }

    public Sprite GetNextBloopSprite()
    {
        return spawnableBloops[nextBloopIndex].GetSprite();
    }

    private Vector2 GetClickedWorldPosition()
    {
        return Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }

    private Vector2 GetSpawnPosition()
    {
        Vector2 clickedWorldPosition = GetClickedWorldPosition();
        clickedWorldPosition.y = bloopYSpawnPos;
        return clickedWorldPosition;
    }

    private void PlaceLineAtClickedPosition()
    {
        bloopDropLine.SetPosition(0, GetSpawnPosition());
        bloopDropLine.SetPosition(1, GetSpawnPosition() + Vector2.down * 15);
    }

    private void HideLine()
    {
        bloopDropLine.enabled= false;
    }

    private void StartControlTimer()
    {
        Invoke("StopControlTimer", spawnDelay);
    }

    private void StopControlTimer()
    {
        canControl = true;
    }

    private void DisplayLine()
    {
        bloopDropLine.enabled = true;
    }

    private void MergeProcessedCallback(BloopType bloopType, Vector2 spawnPosition)
    {
        for (int i = 0; i < bloopPrefabs.Length; i++)
        {
            if (bloopPrefabs[i].GetBloopType() == bloopType)
            {
                SpawnMergedBloop(bloopPrefabs[i], spawnPosition);
                break;
            }
        }
    }   

    private void SpawnMergedBloop(Bloop bloop, Vector2 spawnPosition)
    {
        Bloop bloopInstance = Instantiate(bloop, spawnPosition, Quaternion.identity, bloopParent);
        bloopInstance.EnablePhysics();
    }


#if UNITY_EDITOR

    private void OnDrawGizmos()
    {
        if (!enableGizmos)
            return;

        Gizmos.color = Color.red;
        Gizmos.DrawLine(new Vector3(-50, bloopYSpawnPos, 0), new Vector3(50, bloopYSpawnPos, 0));
    }
    
#endif
}
