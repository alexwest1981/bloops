using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BloopType
{
    Normal,
    Sticky,
    Bouncy,
    Heavy,
    Light,
    Floppy,
    Spiky,
    Ghost,
    Super,
    SuperBouncy,
    SuperHeavy,
    SuperLight,
    SuperFloppy,
    SuperGhost,
    SuperSuper,
    SuperSuperBouncy
}

public enum GameState
{
    Menu,
    Game,
    Gameover
}
